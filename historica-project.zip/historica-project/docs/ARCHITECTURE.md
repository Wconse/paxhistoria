# Архитектура

Браузерное приложение хранит мир как сериализуемый JSON. Сервер агрегирует политии, регионы, войны, действия и чаты в промпт, вызывает модель по роли `jump`, `chat` или `advisor`, затем валидирует JSON. При ошибке включается детерминированный fallback. События применяются по одному, поэтому Save и Intervene безопасны. Рендер отделён от состояния; схематический SVG можно заменить MapLibre и Natural Earth без изменения LLM API.

Зарегистрированные механики: Jump Forward, Auto Jump, Chat, Advisor, Brainstorm, Polish, Next Speaker, Consolidator, Catalyst Creation, Catalyst Runner, Catalyst Summarizer, Game Master.
